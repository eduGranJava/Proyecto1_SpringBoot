package com.example.pry1_springboot;

public class Triangulo implements Figura {
    private double ladoA, ladoB, ladoC;

    public Triangulo(double ladoA, double ladoB, double ladoC) {
        this.ladoA = ladoA; this.ladoB = ladoB; this.ladoC = ladoC;
    }

    public double calcularArea() {
        double s = calcularPerimetro() / 2;
        return Math.sqrt(s * (s - ladoA) * (s - ladoB) * (s - ladoC));
    }

    public double calcularPerimetro() {
        return ladoA + ladoB + ladoC;
    }
}
