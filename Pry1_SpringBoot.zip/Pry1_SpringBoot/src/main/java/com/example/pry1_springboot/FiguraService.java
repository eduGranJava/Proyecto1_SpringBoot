package com.example.pry1_springboot;

import groovy.lang.GroovyClassLoader;
import org.springframework.stereotype.Service;
import java.lang.reflect.Constructor;

@Service
public class FiguraService {
    public Figura instanciarFiguraNativa(String nombreClase, double... parametros) throws Exception {
        Class clase = Class.forName("com.example.pry1_springboot." + nombreClase);
        return instanciar(clase, parametros);
    }

    public Figura instanciarFiguraGroovy(String codigo, double... parametros) throws Exception {
        try (GroovyClassLoader loader = new GroovyClassLoader()) {
            Class claseDinamica = loader.parseClass(codigo);
            return instanciar(claseDinamica, parametros);
        }
    }

    private Figura instanciar(Class clase, double[] parametros) throws Exception {
        for (Constructor c : clase.getConstructors()) {
            if (c.getParameterCount() == parametros.length) {
                Object[] args = new Object[parametros.length];
                for (int i = 0; i < parametros.length; i++) args[i] = parametros[i];
                return (Figura) c.newInstance(args);
            }
        }
        throw new IllegalArgumentException("Constructor no encontrado");
    }
}