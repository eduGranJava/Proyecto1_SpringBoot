package com.example.pry1_springboot;

public interface Figura {
    double calcularArea();
    double calcularPerimetro();
}
