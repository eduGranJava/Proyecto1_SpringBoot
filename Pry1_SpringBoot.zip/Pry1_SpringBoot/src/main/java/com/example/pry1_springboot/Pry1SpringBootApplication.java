package com.example.pry1_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pry1SpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Pry1SpringBootApplication.class, args);
    }

}
