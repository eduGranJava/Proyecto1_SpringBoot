package com.example.pry1_springboot;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/figuras")
public class FiguraController {
    private final FiguraService figuraService;

    public FiguraController(FiguraService figuraService) {
        this.figuraService = figuraService;
    }

    @GetMapping("/crear")
    public String crearNativa(@RequestParam String nombre, @RequestParam double[] valores) {
        try {
            Figura f = figuraService.instanciarFiguraNativa(nombre, valores);
            return "Figura: " + nombre + " | Área: " + f.calcularArea() + " | Perímetro: " + f.calcularPerimetro();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    @PostMapping("/crear-groovy")
    public String crearGroovy(@RequestBody String codigo, @RequestParam double[] valores) {
        try {
            Figura f = figuraService.instanciarFiguraGroovy(codigo, valores);
            return "Groovy Creado | Área: " + f.calcularArea() + " | Perímetro: " + f.calcularPerimetro();
        } catch (Exception e) {
            return "Error Groovy: " + e.getMessage();
        }
    }
}