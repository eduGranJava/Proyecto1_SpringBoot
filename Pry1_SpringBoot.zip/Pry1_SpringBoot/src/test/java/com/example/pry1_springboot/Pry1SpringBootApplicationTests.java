package com.example.pry1_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pry1SpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
